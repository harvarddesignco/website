$("#landing-carousel").carousel({
    interval: 3000
});
 
