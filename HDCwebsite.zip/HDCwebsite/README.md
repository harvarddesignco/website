HDC Website 2020

Colors:
Off-white: #FFFFED
Pink: #DB3069
Yellow: #FFDA0A
Teal: #07A0C3
Indigo-blue: #3D00F4
Navy: #0A004F
